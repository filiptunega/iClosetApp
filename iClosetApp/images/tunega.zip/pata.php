<footer>
    <p>&copy; 2025 Pizza Shop</p>
</footer>
</body>
</html>
