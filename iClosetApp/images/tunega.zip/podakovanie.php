<?php
include "data.php";
include "funkcie.php";
include "hlavicka.php";

$chyba = false;

if (!isset($_POST['meno'], $_POST['telefon'], $_POST['datum'], $_POST['pizza']) || count($_POST['pizza']) === 0) {
    $chyba = true;
}

if (!$chyba) {
    $meno = htmlspecialchars($_POST['meno']);
    $telefon = htmlspecialchars($_POST['telefon']);
    $datum = $_POST['datum'];
    $vybrane = $_POST['pizza'];
    $dni = spocitajDni($datum);

    if ($dni < 0) {
        echo "<p style='color:red'>Dátum dodania musí byť dnešný alebo neskorší!</p>";
        $chyba = true;
    }

    if (!$chyba) {
        echo "<h2>Ďakujeme za objednávku, $meno!</h2>";
        echo "<p>Telefón: $telefon</p>";
        echo "<p>Dodanie o $dni dní (dňa $datum)</p>";
        echo "<ul>";
        foreach ($vybrane as $index) {
            $nazov = $pizzaNazvy[$index];
            $cena = $pizzaCeny[$index];
            echo "<li>$nazov - $cena €</li>";
        }
        echo "</ul>";
        $suma = vypocitajCenu($vybrane, $pizzaCeny);
        echo "<strong>Celková cena: $suma €</strong>";
    }
}

if ($chyba) {
    echo "<p style='color:red'>Skontrolujte prosím všetky povinné údaje a vyberte aspoň jednu pizzu.</p>";
    echo "<p><a href='objednavka.php'>Späť na objednávku</a></p>";
}

include "pata.php";
?>
