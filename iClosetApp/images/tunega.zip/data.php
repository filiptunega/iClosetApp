<?php
$pizzaNazvy = ["Margherita", "Quattro Formaggi", "Pepperoni", "Hawaiian"];
$pizzaCeny = [6.50, 8.00, 7.50, 7.00];
?>
