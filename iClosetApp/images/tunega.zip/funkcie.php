<?php
function vypocitajCenu($vybranePizze, $pizzaCeny) {
    $suma = 0;
    foreach ($vybranePizze as $index) {
        $suma += $pizzaCeny[$index];
    }
    return $suma;
}

function spocitajDni($datumDodania) {
    $dnes = new DateTime();
    $dodanie = DateTime::createFromFormat('Y-m-d', $datumDodania);
    if (!$dodanie) return false;
    $rozdiel = $dnes->diff($dodanie);
    return $rozdiel->days * ($dodanie > $dnes ? 1 : -1);
}
?>
