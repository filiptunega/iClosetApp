<?php
include "data.php";
include "funkcie.php";
include "hlavicka.php";
?>

<form method="post" action="podakovanie.php">
    <fieldset>
        <legend>Vyber si pizzu (max. 1x každú)</legend>
        <?php
        foreach ($pizzaNazvy as $index => $nazov) {
            echo "<label><input type='checkbox' name='pizza[]' value='$index'> $nazov ({$pizzaCeny[$index]} €)</label><br>";
        }
        ?>
    </fieldset>

    <fieldset>
        <legend>Údaje o zákazníkovi</legend>
        <label>Meno: <input type="text" name="meno" required></label><br>
        <label>Telefón: <input type="tel" name="telefon" required pattern="[0-9+ ]{8,}"></label><br>
        <label>Dátum dodania: <input type="date" name="datum" required></label>
    </fieldset>

    <button type="submit">Odoslať objednávku</button>
</form>

<?php include "pata.php"; ?>
