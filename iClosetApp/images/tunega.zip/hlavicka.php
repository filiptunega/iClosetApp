<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <title>Objednávka pizze</title>
</head>
<body>
<h1>Objednaj si pizzu</h1>
